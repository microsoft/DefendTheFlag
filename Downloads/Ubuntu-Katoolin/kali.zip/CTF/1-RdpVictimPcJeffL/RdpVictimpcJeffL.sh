xfreerdp /u:CONTOSO\\JeffL /v:10.0.24.8 /p:'Password$fun'
