xfreerdp /u:CONTOSO\\JeffL /v:10.0.24.10 /p:'Password$fun'
