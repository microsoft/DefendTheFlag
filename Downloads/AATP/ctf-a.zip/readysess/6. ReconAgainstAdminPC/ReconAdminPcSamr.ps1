﻿# requires PowerSploit to be in respective folder...

$AdminPcIp = Resolve-DnsName 'adminpc'
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force
Import-Module C:\Tools\PowerSploit\PowerSploit.psm1
$admins = Get-NetLocalGroup $AdminPcIp.IPAddress